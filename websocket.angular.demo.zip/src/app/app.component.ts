import { Component } from '@angular/core';

import * as socketIo from 'socket.io-client';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'WebsocketTest';
  private socket;

  numberOfLikes = '0';

  constructor(private http: HttpClient) {
    this.socket = socketIo('http://localhost:3000/');

    this.socket.on('events', (data: string) => {
      this.numberOfLikes = data;
      console.log('Received by Websocket: ' + data);
    });
  }

  public send(): void {

    this.http
      .put('http://localhost:3000/user-activity/like-or-dislike/',
        {
          userId: '5e205281639508db75812c40',
          mediaId: '5e205f96371a623cc66d47b4'
        }, {
        headers: {
          'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI1ZTIwNDllZjRhZTk3YWNiMGQzOGFjMmQiLCJpYXQiOjE1NzkxNzQ0MTQsImV4cCI6MTU3OTIxMDQxNH0.C0kPaDhC1Mo9WXJjTUgcuk2c7OhfYRYCfakd7JsRUTI'
        }
      }).subscribe(
        x => {
          console.log(x);
        },
        err => {
          console.log(err);
        });

  }

}
